"""
Flask APIサーバー - stationsデータベースからデータを提供
"""

from flask import Flask, jsonify, request
from flask_cors import CORS
from database_connection import DatabaseConnection
import os

app = Flask(__name__)
CORS(app)  # CORSを有効化してフロントエンドからのアクセスを許可

# MySQL接続情報
MYSQL_CONFIG = {
    "host": "localhost",
    "port": 3306,
    "user": "root",
    "password": "Taisei0611",
    "database": "station"
}


@app.route('/api/stations', methods=['GET'])
def get_stations():
    """全駅データを取得"""
    try:
        limit = request.args.get('limit', default=100, type=int)
        offset = request.args.get('offset', default=0, type=int)
        prefecture = request.args.get('prefecture', default=None, type=str)
        
        db = DatabaseConnection(**MYSQL_CONFIG)
        
        query = "SELECT * FROM stations WHERE 1=1"
        params = []
        
        if prefecture:
            query += " AND prefecture = %s"
            params.append(prefecture)
        
        query += " LIMIT %s OFFSET %s"
        params.extend([limit, offset])
        
        stations = db.execute_query(query, tuple(params) if params else None)
        db.close()
        
        return jsonify({
            "success": True,
            "data": stations,
            "count": len(stations)
        })
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


@app.route('/api/stations/<int:station_id>', methods=['GET'])
def get_station(station_id):
    """特定の駅データを取得"""
    try:
        db = DatabaseConnection(**MYSQL_CONFIG)
        stations = db.execute_query(
            "SELECT * FROM stations WHERE id = %s",
            (station_id,)
        )
        db.close()
        
        if stations:
            return jsonify({
                "success": True,
                "data": stations[0]
            })
        else:
            return jsonify({
                "success": False,
                "error": "Station not found"
            }), 404
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


@app.route('/api/stations/count', methods=['GET'])
def get_stations_count():
    """駅の総数を取得"""
    try:
        db = DatabaseConnection(**MYSQL_CONFIG)
        result = db.execute_query("SELECT COUNT(*) as total FROM stations")
        db.close()
        
        return jsonify({
            "success": True,
            "count": result[0]['total']
        })
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


@app.route('/api/stations/prefectures', methods=['GET'])
def get_prefectures():
    """都道府県一覧を取得"""
    try:
        db = DatabaseConnection(**MYSQL_CONFIG)
        prefectures = db.execute_query("""
            SELECT prefecture, COUNT(*) as count 
            FROM stations 
            WHERE prefecture IS NOT NULL 
            GROUP BY prefecture 
            ORDER BY count DESC
        """)
        db.close()
        
        return jsonify({
            "success": True,
            "data": prefectures
        })
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


@app.route('/api/stations/statistics', methods=['GET'])
def get_statistics():
    """バリアフリー設備の統計を取得"""
    try:
        db = DatabaseConnection(**MYSQL_CONFIG)
        stats = db.execute_query("""
            SELECT 
                COUNT(*) as total_stations,
                SUM(CASE WHEN has_tactile_paving = 1 THEN 1 ELSE 0 END) as with_tactile_paving,
                SUM(CASE WHEN has_guidance_system = 1 THEN 1 ELSE 0 END) as with_guidance_system,
                SUM(CASE WHEN has_accessible_restroom = 1 THEN 1 ELSE 0 END) as with_accessible_restroom,
                SUM(CASE WHEN has_accessible_gate = 1 THEN 1 ELSE 0 END) as with_accessible_gate,
                SUM(CASE WHEN num_elevators > 0 THEN 1 ELSE 0 END) as with_elevators
            FROM stations
        """)
        db.close()
        
        return jsonify({
            "success": True,
            "data": stats[0] if stats else {}
        })
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


@app.route('/api/stations/search', methods=['GET'])
def search_stations():
    """駅名で検索"""
    try:
        keyword = request.args.get('keyword', default='', type=str)
        limit = request.args.get('limit', default=50, type=int)
        
        if not keyword:
            return jsonify({
                "success": False,
                "error": "Keyword parameter is required"
            }), 400
        
        db = DatabaseConnection(**MYSQL_CONFIG)
        stations = db.execute_query(
            "SELECT * FROM stations WHERE station_name LIKE %s LIMIT %s",
            (f"%{keyword}%", limit)
        )
        db.close()
        
        return jsonify({
            "success": True,
            "data": stations,
            "count": len(stations)
        })
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


if __name__ == '__main__':
    print("Flask APIサーバーを起動します...")
    print("http://localhost:5000 でアクセスできます")
    app.run(debug=True, port=5000)

