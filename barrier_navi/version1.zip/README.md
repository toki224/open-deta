# 駅データ表示アプリケーション

MySQLデータベースの駅データを表示するWebアプリケーションです。

## 構成

- **バックエンド**: Python Flask APIサーバー
- **フロントエンド**: TypeScript + HTML + CSS
- **データベース**: MySQL (stationデータベース)

## セットアップ

### 1. Pythonパッケージのインストール

```bash
py -m pip install -r requirements.txt
```

### 2. Node.jsとTypeScriptのインストール

Node.jsがインストールされていない場合は、[Node.js公式サイト](https://nodejs.org/)からインストールしてください。

Node.jsをインストール後、TypeScriptをインストール：

```bash
npm install -g typescript
```

または、プロジェクトローカルにインストール：

```bash
npm install
```

### 3. TypeScriptのビルド

```bash
npm run build
```

または、TypeScriptがグローバルにインストールされている場合：

```bash
tsc
```

これで`dist/index.js`が生成されます。

## 実行方法

### 1. APIサーバーの起動

```bash
py api_server.py
```

APIサーバーは `http://localhost:5000` で起動します。

### 2. ブラウザで表示

`index.html`をブラウザで開いてください。

または、簡単なHTTPサーバーを使用する場合：

```bash
# Python 3の場合
py -m http.server 8000
```

その後、ブラウザで `http://localhost:8000` にアクセスしてください。

## 機能

- 駅データの一覧表示
- 駅名での検索
- 都道府県での絞り込み
- バリアフリー設備の統計表示
- ページネーション

## APIエンドポイント

- `GET /api/stations` - 駅データ一覧を取得
- `GET /api/stations/<id>` - 特定の駅データを取得
- `GET /api/stations/count` - 駅の総数を取得
- `GET /api/stations/prefectures` - 都道府県一覧を取得
- `GET /api/stations/statistics` - バリアフリー設備の統計を取得
- `GET /api/stations/search?keyword=<keyword>` - 駅名で検索

## ファイル構成

```
.
├── api_server.py          # Flask APIサーバー
├── database_connection.py  # データベース接続クラス
├── index.html             # メインHTMLファイル
├── styles.css             # スタイルシート
├── src/
│   └── index.ts          # TypeScriptソースコード
├── dist/
│   └── index.js          # コンパイル後のJavaScript（ビルド後に生成）
├── package.json          # Node.js依存関係
├── tsconfig.json         # TypeScript設定
└── requirements.txt     # Python依存関係
```

## 開発

TypeScriptファイルを変更した場合は、再度ビルドが必要です：

```bash
npm run build
```

または、ウォッチモードで自動ビルド：

```bash
npm run watch
```

## 注意事項

- MySQLサーバーが起動していることを確認してください
- `api_server.py`内のMySQL接続情報を環境に合わせて設定してください
- CORSは開発環境用に有効化されています。本番環境では適切に設定してください
