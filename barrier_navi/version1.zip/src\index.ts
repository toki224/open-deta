/**
 * 駅データ表示アプリケーション
 */

interface Station {
  id: number;
  railway_operator: string;
  station_name: string;
  line_name: string;
  prefecture: string;
  city: string;
  step_response_status: number;
  num_platforms: number;
  num_step_free_platforms: number;
  num_elevators: number;
  num_compliant_elevators: number;
  num_escalators: number;
  num_compliant_escalators: number;
  num_other_lifts: number;
  num_slopes: number;
  num_compliant_slopes: number;
  has_tactile_paving: number;
  has_guidance_system: number;
  has_accessible_restroom: number;
  has_accessible_gate: number;
  has_accessible_ticket_machine: number;
  num_wheelchair_accessible_platforms: number;
  has_fall_prevention: number;
}

interface ApiResponse<T> {
  success: boolean;
  data?: T;
  count?: number;
  error?: string;
}

interface Statistics {
  total_stations: number;
  with_tactile_paving: number;
  with_guidance_system: number;
  with_accessible_restroom: number;
  with_accessible_gate: number;
  with_elevators: number;
}

class StationApp {
  private apiBaseUrl = 'http://localhost:5000/api';
  private currentPage = 1;
  private pageSize = 20;
  private selectedPrefecture: string | null = null;

  constructor() {
    this.init();
  }

  private async init(): Promise<void> {
    this.setupEventListeners();
    await this.loadStatistics();
    await this.loadPrefectures();
    await this.loadStations();
  }

  private setupEventListeners(): void {
    const searchButton = document.getElementById('search-btn') as HTMLButtonElement;
    const searchInput = document.getElementById('search-input') as HTMLInputElement;
    const prefectureSelect = document.getElementById('prefecture-select') as HTMLSelectElement;
    const prevButton = document.getElementById('prev-btn') as HTMLButtonElement;
    const nextButton = document.getElementById('next-btn') as HTMLButtonElement;

    searchButton?.addEventListener('click', () => this.handleSearch());
    searchInput?.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') this.handleSearch();
    });

    prefectureSelect?.addEventListener('change', (e) => {
      this.selectedPrefecture = (e.target as HTMLSelectElement).value || null;
      this.currentPage = 1;
      this.loadStations();
    });

    prevButton?.addEventListener('click', () => {
      if (this.currentPage > 1) {
        this.currentPage--;
        this.loadStations();
      }
    });

    nextButton?.addEventListener('click', () => {
      this.currentPage++;
      this.loadStations();
    });
  }

  private async fetchApi<T>(endpoint: string): Promise<ApiResponse<T>> {
    try {
      const response = await fetch(`${this.apiBaseUrl}${endpoint}`);
      return await response.json();
    } catch (error) {
      console.error('API Error:', error);
      return { success: false, error: String(error) };
    }
  }

  private async loadStatistics(): Promise<void> {
    const response = await this.fetchApi<Statistics>('/stations/statistics');
    if (response.success && response.data) {
      this.displayStatistics(response.data);
    }
  }

  private displayStatistics(stats: Statistics): void {
    const statsContainer = document.getElementById('statistics');
    if (!statsContainer) return;

    statsContainer.innerHTML = `
      <div class="stat-card">
        <h3>総駅数</h3>
        <p class="stat-number">${stats.total_stations.toLocaleString()}</p>
      </div>
      <div class="stat-card">
        <h3>エレベーター設置</h3>
        <p class="stat-number">${stats.with_elevators.toLocaleString()}</p>
      </div>
      <div class="stat-card">
        <h3>視覚障害者誘導用ブロック</h3>
        <p class="stat-number">${stats.with_tactile_paving.toLocaleString()}</p>
      </div>
      <div class="stat-card">
        <h3>案内設備</h3>
        <p class="stat-number">${stats.with_guidance_system.toLocaleString()}</p>
      </div>
      <div class="stat-card">
        <h3>障害者対応型便所</h3>
        <p class="stat-number">${stats.with_accessible_restroom.toLocaleString()}</p>
      </div>
      <div class="stat-card">
        <h3>障害者対応型改札口</h3>
        <p class="stat-number">${stats.with_accessible_gate.toLocaleString()}</p>
      </div>
    `;
  }

  private async loadPrefectures(): Promise<void> {
    const response = await this.fetchApi<Array<{ prefecture: string; count: number }>>('/stations/prefectures');
    if (response.success && response.data) {
      const select = document.getElementById('prefecture-select') as HTMLSelectElement;
      if (select) {
        select.innerHTML = '<option value="">すべての都道府県</option>';
        response.data.forEach(item => {
          const option = document.createElement('option');
          option.value = item.prefecture;
          option.textContent = `${item.prefecture} (${item.count}駅)`;
          select.appendChild(option);
        });
      }
    }
  }

  private async loadStations(): Promise<void> {
    const loadingIndicator = document.getElementById('loading');
    const stationsContainer = document.getElementById('stations-list');
    
    if (loadingIndicator) loadingIndicator.style.display = 'block';
    if (stationsContainer) stationsContainer.innerHTML = '';

    const offset = (this.currentPage - 1) * this.pageSize;
    let endpoint = `/stations?limit=${this.pageSize}&offset=${offset}`;
    
    if (this.selectedPrefecture) {
      endpoint += `&prefecture=${encodeURIComponent(this.selectedPrefecture)}`;
    }

    const response = await this.fetchApi<Station[]>(endpoint);
    
    if (loadingIndicator) loadingIndicator.style.display = 'none';

    if (response.success && response.data) {
      this.displayStations(response.data);
      this.updatePagination();
    } else {
      if (stationsContainer) {
        stationsContainer.innerHTML = `<p class="error">データの取得に失敗しました: ${response.error}</p>`;
      }
    }
  }

  private displayStations(stations: Station[]): void {
    const container = document.getElementById('stations-list');
    if (!container) return;

    if (stations.length === 0) {
      container.innerHTML = '<p class="no-data">データが見つかりませんでした。</p>';
      return;
    }

    container.innerHTML = stations.map(station => `
      <div class="station-card">
        <div class="station-header">
          <h3>${this.escapeHtml(station.station_name)}</h3>
          <span class="operator">${this.escapeHtml(station.railway_operator)}</span>
        </div>
        <div class="station-info">
          <p><strong>路線:</strong> ${this.escapeHtml(station.line_name)}</p>
          <p><strong>所在地:</strong> ${this.escapeHtml(station.prefecture)} ${this.escapeHtml(station.city)}</p>
        </div>
        <div class="station-facilities">
          <div class="facility-item">
            <span class="facility-label">プラットホーム:</span>
            <span class="facility-value">${station.num_platforms || 0}基</span>
          </div>
          <div class="facility-item">
            <span class="facility-label">エレベーター:</span>
            <span class="facility-value">${station.num_elevators || 0}基</span>
          </div>
          <div class="facility-item">
            <span class="facility-label">エスカレーター:</span>
            <span class="facility-value">${station.num_escalators || 0}基</span>
          </div>
        </div>
        <div class="station-accessibility">
          ${station.has_tactile_paving ? '<span class="badge">視覚障害者誘導用ブロック</span>' : ''}
          ${station.has_guidance_system ? '<span class="badge">案内設備</span>' : ''}
          ${station.has_accessible_restroom ? '<span class="badge">障害者対応型便所</span>' : ''}
          ${station.has_accessible_gate ? '<span class="badge">障害者対応型改札口</span>' : ''}
        </div>
      </div>
    `).join('');
  }

  private updatePagination(): void {
    const pageInfo = document.getElementById('page-info');
    const prevButton = document.getElementById('prev-btn') as HTMLButtonElement;
    const nextButton = document.getElementById('next-btn') as HTMLButtonElement;

    if (pageInfo) {
      pageInfo.textContent = `ページ ${this.currentPage}`;
    }

    if (prevButton) {
      prevButton.disabled = this.currentPage === 1;
    }

    // 次のページがあるかどうかは実際のデータ取得結果で判断する必要があります
    // ここでは簡易的に常に有効にしています
    if (nextButton) {
      nextButton.disabled = false;
    }
  }

  private async handleSearch(): Promise<void> {
    const searchInput = document.getElementById('search-input') as HTMLInputElement;
    const keyword = searchInput?.value.trim();

    if (!keyword) {
      await this.loadStations();
      return;
    }

    const loadingIndicator = document.getElementById('loading');
    const stationsContainer = document.getElementById('stations-list');
    
    if (loadingIndicator) loadingIndicator.style.display = 'block';
    if (stationsContainer) stationsContainer.innerHTML = '';

    const response = await this.fetchApi<Station[]>(`/stations/search?keyword=${encodeURIComponent(keyword)}`);
    
    if (loadingIndicator) loadingIndicator.style.display = 'none';

    if (response.success && response.data) {
      this.displayStations(response.data);
      const pageInfo = document.getElementById('page-info');
      if (pageInfo) {
        pageInfo.textContent = `検索結果: ${response.count || 0}件`;
      }
    } else {
      if (stationsContainer) {
        stationsContainer.innerHTML = `<p class="error">検索に失敗しました: ${response.error}</p>`;
      }
    }
  }

  private escapeHtml(text: string | null | undefined): string {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }
}

// ページ読み込み時にアプリを初期化
document.addEventListener('DOMContentLoaded', () => {
  new StationApp();
});

